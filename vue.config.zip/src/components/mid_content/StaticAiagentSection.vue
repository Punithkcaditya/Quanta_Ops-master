<template>
    <section class="ai-network">
      <h2 class="title">Transforming Enterprises</h2>
      <h1 class="subtitle">AI Agent For Operations</h1>
  
      <div class="network-container">
        <!-- Central Management Agent -->
        <div class="agent center">
            <img src="@/assets/ai-network-bg.png" alt="screw" class="icon-screw" />
        </div>
      </div>
  
      <!-- <p class="footer-text">AI agents for operations by Quanta Ops</p> -->
    </section>
  </template>
  
  <script>
  export default {
  name: "StaticAiagentSection",
  };
  </script>
  
  <style scoped>
  .ai-network{
    padding: 7em;
  }

  .agent.center img{
width: 51%;
  }
  </style>
  